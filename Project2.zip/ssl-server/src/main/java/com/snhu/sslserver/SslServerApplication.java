package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.MessageDigest;

@SpringBootApplication
@RestController
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

	@GetMapping("/hash")
	public String getHash() {

	    String name = "Johnathan Smith";
	    String uniqueData = "SecureData2026";

	    String combined = name + uniqueData;

	    String checksum = ChecksumUtil.getChecksum(combined);

	    return "<h1>Name: " + name + "</h1>"
	    + "<h2>Unique Data: " + uniqueData + "</h2>"
	    + "<h2>Algorithm: SHA-256</h2>"
	    + "<h2>Checksum: " + checksum + "</h2>";
	}

	static class ChecksumUtil {

		public static String getChecksum(String input) {

			try {

				MessageDigest digest = MessageDigest.getInstance("SHA-256");

				byte[] hash = digest.digest(input.getBytes("UTF-8"));

				StringBuilder hexString = new StringBuilder();

				for (byte b : hash) {

					String hex = Integer.toHexString(0xff & b);

					if (hex.length() == 1) hexString.append('0');

					hexString.append(hex);
				}

				return hexString.toString();

			} catch (Exception e) {

				throw new RuntimeException(e);
			}
		}
	}
}