package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServerController {

    @GetMapping("/hash")
    public String getHash() {
        String data = "Johnathan Smith";
        String checksum = computeChecksum(data); // compute hash
        // Build the response string here
        return "data: " + data + "\n\nName of Cipher Algorithm Used: SHA-256\nCheckSum Value: " + checksum;
    }

    private String computeChecksum(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if(hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString(); // only return the checksum
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}

